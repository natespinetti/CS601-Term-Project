package LinkedList;

public class Hw2_p3 {

	// reverse method has DoublyLinkedList argument
	// reverse method runs recursiveHelper method with intList and Header node as arguments
	// input: recursiveHelper method
	// output: the reverse of intList
	public static void reverse(DoublyLinkedList<Integer> intList) {

		recursiveHelper(intList, intList.getHeader());
	}

	// recursiveHelper method has DoublyLinkedList and DoubleLinkNode arguments
	// sets Node trailer = the trailer of intList
	// sets Node last = node before trailer
	// if last node = index node, end recursion
	// else, sets Last as trailer
		// sets node prior to trailer to new Last node
		// sets trailer to node after index
		// index is set to last
		// node after index set to last
		// node before last set to index
		// index is equal to last
		// recursive method runs until if statement is met
	// input: intList
	// output: nodes are rearranged
	public static void recursiveHelper(DoublyLinkedList<Integer> intList, DoubleLinkNode index){

		DoubleLinkNode<Integer> trailer = intList.getTrailer();
		DoubleLinkNode<Integer> last = trailer.getPrev();

		if (last == index) {
			return;
		}
		else {
			last.getPrev().setNext(trailer);
			trailer.setPrev(last.getPrev());

			last.setNext(index.getNext());
			index.getNext().setPrev(last);
			index.setNext(last);
			last.setPrev(index);

			index = last;

			recursiveHelper(intList, index);
		}

	}
	
	// intList is set to DoublyLinkedList
	// array a is set. for loop goes through the length of the array
		// adds a[i] to last node, before trailer
		// prints intList size and array as string to console
	// reverse method runs with intList as argument
	// prints 'reverse' of intList as a string
	// intList set to new DoublyLinkedList. array b is set
		// for loop goes through the length of the array
		// adds a[i] to last node, before trailer
		// prints intList size and array as string to console
	// reverse method runs with intList as argument
	// prints 'reverse' of intList as a string
	// input: intList, array a and b
	// output: printing original intList and the reverse
	public static void main(String[] args) {

		
		DoublyLinkedList<Integer> intList = new DoublyLinkedList<>();
		
		int[] a = {10, 20, 30, 40, 50};
		for (int i=0; i<a.length; i++) {
			intList.addLast(a[i]);
		}
		System.out.println("Initial list: size = " + intList.size() + ", " + intList.toString());
		
		// Here, invoke the reverse method you implemented above
		reverse(intList);
		
		System.out.println("After reverse: " + intList.toString());
		
		intList = new DoublyLinkedList<>();
		int[] b = {10, 20, 30, 40, 50, 60};
		for (int i=0; i<b.length; i++) {
			intList.addLast(b[i]);
		}
		System.out.println();
		System.out.println("Initial list: size = " + intList.size() + ", " + intList.toString());
		
		// Here, invoke the reverse method you implemented above
		reverse(intList);
		
		System.out.println("After reverse: " + intList.toString());

	}

}
