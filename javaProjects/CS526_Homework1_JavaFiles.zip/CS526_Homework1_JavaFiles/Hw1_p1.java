package spring2021.penny;

public class Hw1_p1 {


	// Initialize boolean doesNotExist to false.
	// Begin for loop that initializes i to 0. Set boolean statement to be value of i is less than length of the array. Update expression to be i+1
		// if position in array is = to x, print x is in i. Update doesNotExist boolean to true.
	// Outside of for loop, if boolean is false print x does not exist.
	// Inputs = each cell to verify the value as it loops
	// Outputs = the cells that have an equal value to x
	public static void find(int[] a, int x) {
		boolean doesNotExist = false;
		for(int i=0; i < a.length; i++){
			if(a[i] == x) {
				System.out.println(x + " is in a[" + i + "]");
				doesNotExist = true;
			}
		}
		if (!doesNotExist) System.out.println(x + " does not exist");
	}


	// String s2 begins with String s1 - Returns
	// Inputs = String s1 and s2
	// Outputs = s2 has a prefix of s1
	public static boolean isPrefix(String s1, String s2) {

		return s2.startsWith(s1);
	}

	
	// Sets array values
	// runs find method with x as 5
	// runs find method with x as 10 (print extra space)
	// s1, s2, s3 values initialized
	// if isPrefix method s1,s2 is/ is not prefix, prints statement
	// if isPrefix method s1,s3 is/ is not prefix, prints statement
	public static void main(String[] args) {
		
		int[] a = {5, 3, 5, 6, 1, 2, 12, 5, 6, 1};
		
		find(a, 5);
		find(a, 10);
		System.out.println();
		
		String s1 = "abc";
		String s2 = "abcde";
		String s3 = "abdef";
		
		if (isPrefix(s1,s2)) {
			System.out.println(s1 + " is a prefix of " + s2);
		}
		else {
			System.out.println(s1 + " is not a prefix of " + s2);
		}
		
		if (isPrefix(s1,s3)) {
			System.out.println(s1 + " is a prefix of " + s3);
		}
		else {
			System.out.println(s1 + " is not a prefix of " + s3);
		}
	}
}
