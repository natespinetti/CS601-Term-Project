import java.util.ArrayList;

// defining the Node
public class Node {
    char data;
    ArrayList<Character> arrList;

    // constructor assigns value passed and creates empty arraylist
    public Node(char data) {
        this.data = data;
        this.arrList = new ArrayList<Character>();
    }
}
