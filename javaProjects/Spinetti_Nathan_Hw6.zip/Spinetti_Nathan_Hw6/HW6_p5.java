import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;


public class HW6_p5 {


        // gets index of the node in the adjList
        public static int getIndex(char person, ArrayList<Node> adjList){
            int index = 0;
            for (int i = 0; i < adjList.size(); i++){   // loop through list
                if (adjList.get(i).data == person){     // if the node data at i = person, index = i;
                    index = i;
                }
            }
            return index;   // returns index of person in list
        }



        // Helper method for DFS
        public static void DFSHelper(char person, ArrayList<Node> adjList, int[] visited){
            int index = getIndex(person, adjList);  // index = person

            if (visited[index] == 0){
                visited[index] = 1; // 1 is visited
            }

            // Helper on each person in arrList
            for (Character ch : adjList.get(index).arrList){
                DFSHelper(ch, adjList, visited);
            }
        }



        // DFS method
        public static String DFS(int index, ArrayList<Character> arrList, ArrayList<Node> adjList) {

            int[] visited = new int[adjList.size()]; // visited is size of adjList
            visited[index] = 0;

            // for each person in arrList, ind = person, person set to 0, calls helper
            for (Character ch : arrList) {

                int ind = getIndex(ch, adjList);
                visited[ind] = 0;
                DFSHelper(ch, adjList, visited);

            }

            String list = ""; // empty string

            // traverse length of visited array
            for (int i = 0; i < visited.length; i++){

                // if the person has been visited, add that visited person to the indirect list
                if (visited[i] == 1){
                    list = list + adjList.get(i).data + ", ";
                }
            }

            // this will remove the extra comment and space from the list if there are no others visited
            if (list.length() > 0){
                list = list.substring(0, list.length()-2);
            }

            return list;
        }



        // method determines if its a direct or indirect follow
        public static void allFollows(char person, ArrayList<Node> adjList){

            int ind = getIndex(person, adjList);    // ind = person

            // DIRECT FOLLOW
            String list = "";   // empty string

            // add each direct connect persons to list string
            for (Character ch : adjList.get(ind).arrList){
                list = list + ch + ", ";
            }

            // removes extra comma and space if its the last person
            if (list.length() > 0){
                list = list.substring(0, list.length()-2);
            }

            // print 'person' and add who directly follows it from the list
            System.out.println(person + " directly follows {"+list+"}");


            // INDIRECT FOLLOW
            // make list equal to new DFS call to return indirect connections
            list = DFS(ind, adjList.get(ind).arrList, adjList);

            // print the indirect connections from new list
            System.out.println(person + " indirectly follows {"+list+"}");

        }



        // main method to scan and determine follows from file
    public static void main(String[] args) throws FileNotFoundException{

        ArrayList<Node> adjList = new ArrayList<>();    // new arraylist of type node

        File file = new File("follows_input.txt");  // points to the follows_input file
        Scanner scan = new Scanner(file);   // scans the file defined above

        int pos = 0;    // set position to 0

        // while loop scanning each line one at a time
        while (scan.hasNextLine()){
            String s = scan.nextLine(); // string equal to next line

            String[] sArray = s.split(", ");    // string array that splits string by comma and space

            adjList.add(new Node(sArray[0].charAt(0))); // add node to list using first character in line

            // traverse length of string array
            for (int i = 0; i < sArray.length; i++){

                // adds nodes to arrList that have the direct edge w node in adjList
                if (i == 0)
                    continue;
                    adjList.get(pos).arrList.add(sArray[i].charAt(0));

            }
            pos++;
        }

        // Prints every person
        allFollows('A', adjList);
        System.out.println();
        allFollows('B', adjList);
        System.out.println();
        allFollows('C', adjList);
        System.out.println();
        allFollows('D', adjList);
        System.out.println();
        allFollows('E', adjList);
        System.out.println();
        allFollows('F', adjList);
        System.out.println();
        allFollows('G', adjList);
        System.out.println();
        allFollows('H', adjList);
        System.out.println();


    }


}
