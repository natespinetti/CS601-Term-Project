
// Entry interface with key and value
public interface Entry<K,V> {

    K getKey();
    V getValue();

}
