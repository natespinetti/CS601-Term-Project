import java.util.ArrayList;

// HeapPQ extends Abstract
public class HeapPriorityQueue<K,V> extends AbstractPriorityQueue<K,V> {

    // Entry arraylist (heap)
    protected ArrayList<Entry<K,V>> heap = new ArrayList<>();

    // truncating
    protected int parent(int j) {
        return (j-1) / 2;
    }
    // find left
    protected int left(int j){
        return 2*j + 1;
    }
    // find right
    protected int right(int j){
        return 2*j + 2;
    }
    // left exist
    protected boolean hasLeft(int j){
        return left(j) < heap.size();
    }
    // right exist
    protected boolean hasRight(int j){
        return right(j) < heap.size();
    }


    // swaps index of i and j
    // Input i and j
    // Output j and i
    protected void swap(int i, int j){
        Entry<K,V> temp = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, temp);
    }

    // moves j up
    // Input j
    // Output j from parent location
    protected void upHeap(int j){
        while (j > 0){
            int p = parent(j);

            // checks heap property
            if (compare(heap.get(j), heap.get(p)) >= 0)
                break;

            swap(j, p);
            j = p;  // go from parent location
        }
    }


    // moves j down
    // Input j
    // Output j at smallchildindex at leftmost index
    protected void downHeap(int j){

        while (hasLeft(j)){
            int leftIndex = left(j);
            int smallChildIndex = leftIndex;

            if (hasRight(j)) {
                int rightIndex = right(j);
                if (compare(heap.get(leftIndex), heap.get(rightIndex)) > 0) {
                    smallChildIndex = rightIndex;
                }
            }

            // checks heap property
            if (compare(heap.get(smallChildIndex), heap.get(j)) >= 0){
                    break;
            }

                swap(j, smallChildIndex);

                j = smallChildIndex;
            }
        }


    @Override   // return size of heap
    public int size(){
    return heap.size();
    }

    @Override   // insert newest entry. Input Key and Value. Output PQEntry "newest"
    public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
        Entry<K,V> newest = new PQEntry<>(key, value);
        // add entry to heap
        heap.add(newest);
        // upheap entry
        upHeap(heap.size()-1);
        // return entry
        return newest;
    }


    @Override   // removes minimum entry. Input Key and Value. Output minimum value
    public Entry<K,V> removeMin(){

    if (heap.isEmpty()){
        return null;
    }

    Entry<K,V> answer = heap.get(0);

    swap(0, heap.size()-1);

    heap.remove(heap.size()-1);
    downHeap(0);
    return answer;
    }
}
