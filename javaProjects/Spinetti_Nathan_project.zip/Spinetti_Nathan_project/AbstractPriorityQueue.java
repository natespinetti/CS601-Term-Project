import java.util.Comparator;

// AbstractPW that implements PQ
public abstract class AbstractPriorityQueue<K,V> implements PriorityQueue<K,V> {

    // Priority queue entry implementing Entry interface, get key and get value
    public static class PQEntry<K,V> implements Entry<K,V>{

        private K k; // keys
        private V v; // values

        public PQEntry(K key, V value){
            k = key;
            v = value;
        }

        public K getKey(){
            return k;
        }
        public V getValue(){
            return v;
        }

    }


    private Comparator<K> comp;

    // Comparator for AbstractPQ
    protected AbstractPriorityQueue(Comparator<K> c){
        comp = c;
    }

    protected AbstractPriorityQueue(){
        this(new DefaultComparator<K>());
    }

    // Input compares Entry keys from 2 objects
    // Output compares key of a and b
    protected int compare(Entry<K,V> a, Entry<K,V> b){
        return comp.compare(a.getKey(), b.getKey());
    }

    @Override
    public boolean isEmpty(){
        return size() == 0;
    }

}
