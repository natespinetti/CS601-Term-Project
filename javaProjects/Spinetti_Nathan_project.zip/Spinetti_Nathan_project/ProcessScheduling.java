import java.io.PrintWriter;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ProcessScheduling {

    protected static class Process {

        // private processes
        private int processID;
        private int priority;
        private int duration;
        private int arrivalTime;


        // initialize process pieces
        public Process() {
            processID = 0;
            priority = 0;
            duration = 0;
            arrivalTime = 0;
        }

        // private process = to the public
        public Process(int processID, int priority, int duration, int arrivalTime) {
            this.processID = processID;
            this.priority = priority;
            this.duration = duration;
            this.arrivalTime = arrivalTime;
        }

        public int getID() {    // return id
            return processID;
        }

        public int getPriority() {  // return priority
            return priority;
        }

        public int getDuration() {  // return duration
            return duration;
        }

        public int getArrivalTime() {   // return arrival time
            return arrivalTime;
        }

        // return the process in a string
        public String toString() {
            String s = "ID = " + processID +
                    ", Priority = " + priority +
                    ", Duration = " + duration +
                    ", Arrival Time = " + arrivalTime;
            return s;
        }
    }



    public static void main(String[] args) throws FileNotFoundException {

        // point to file
        File file = new File("process_scheduling_input.txt");
        // scan file
        Scanner processInput = new Scanner(file);
        // print to new file
        PrintWriter processOutput = new PrintWriter("process_scheduling_output.txt");

        // arraylist of processes
        ArrayList<Process> D = new ArrayList<>();

        // read file line by line
        while (processInput.hasNext()){
            String line = processInput.nextLine();
            String[] wholeLine = line.split(" ");   // split contents by space
            // process = each number from string to int
            Process p1 = new Process(Integer.parseInt(wholeLine[0]),
                    Integer.parseInt(wholeLine[1]), Integer.parseInt(wholeLine[2]), Integer.parseInt(wholeLine[3]));
            D.add(p1);  // Output = add to array
        }

        processInput.close();   // close file

        int numProcesses = D.size();
        int maxWait = 30;

        // Output = print each process to new file line by line
        for (int i = 0; i < D.size(); i++){
            processOutput.println(D.get(i));
        }
        processOutput.println();    // empty space
        processOutput.println("Maximum wait time = " + maxWait);    // print max wait
        processOutput.println();    // empty space

        int currentTime = 0;    // start at 0
        boolean running = false;    // is process running
        HeapPriorityQueue<Integer, Process> Q = new HeapPriorityQueue<>();

        Process p = new Process();

        Process runP = new Process();

        int waitTime = 0;   // keep track of times
        double avgWaitTime = 0;
        int endTime = 0;


        // run while D array is not empty
        while (!D.isEmpty()){

            // arrival time of first process
            int early = D.get(0).getArrivalTime();
            int earlyIndex = 0;

            // gets arrival time of each process
            for (int i = 0; i < D.size(); i++){

                int temp = D.get(i).getArrivalTime();

                if (temp < early){
                    early = temp;
                    earlyIndex = i;
                }
            }

            // gets process where earlyIndex is
            p = D.get(earlyIndex);

            // remove p from D and insert to Q
            if (p.getArrivalTime() <= currentTime){
                Q.insert(p.getPriority(), p);
                D.remove(earlyIndex);
            }

            // Q not empty and not running
            if (!Q.isEmpty() && !running){
                // removes process with smallest priority
                runP = Q.removeMin().getValue();

                // determine times for file
                waitTime = currentTime - runP.getArrivalTime();
                avgWaitTime += waitTime;
                endTime = currentTime + runP.getDuration();


                // if wait time is greater than max wait time, update the priority -1 and print
                // Input wait times
                // Output the following printing + priority - 1
                if (waitTime >= maxWait) {

                    processOutput.println("Update priority:");
                    processOutput.println("ID = " + runP.getID() + " , wait time = " +
                            waitTime + " , current priority = " + runP.priority);


                    runP.priority = runP.priority - 1;
                    processOutput.println("ID = " + runP.getID() + " , new priority = " + runP.priority);
                    processOutput.println();
                }

                // write to the file
                processOutput.println("Process removed from queue is: id = " + runP.getID() + ", at time" + currentTime
                + " , wait time = " + waitTime + ", Total wait time = " + avgWaitTime);

                processOutput.println("\tProcess id = " + runP.getID() + "\n\tPriority = " + runP.getPriority() + "\n\tArrival = "
                + runP.getArrivalTime() + "\n\tDuration = " + runP.getDuration());

                // process IS running
                running = true;
            }
            currentTime += 1;   // increment time

            // if running and process has ended
            if (running && endTime == currentTime){
                processOutput.println("Process " + runP.getID() + " finished at time " + endTime + "\n");

                // process IS NOT running
                running = false;
            }

        }


        processOutput.println("\nD is empty at time " + (currentTime-1) + "\n");

        // while Q is not empty
        while (!Q.isEmpty()){
            // if process is not running
            if (!running){
                // remove process w smallest priority
                runP = Q.removeMin().getValue();

                // values to be written
                waitTime = currentTime - runP.getArrivalTime();
                avgWaitTime += waitTime;
                endTime = currentTime + runP.getDuration();

                // write to file
                processOutput.println("Process removed from queue is: id = " + runP.getID() + ", at time " + currentTime +
                        " , wait time = " + waitTime + ", Total wait time = " + avgWaitTime);
                processOutput.println("\tProcess ID = " + runP.getID() + "\n\tPriority = " + runP.getPriority() +
                        ", \n\tArrival = " + runP.getArrivalTime() + "\n\tDuration = " + runP.getDuration());

                // process IS running
                running = true;
            }

            currentTime += 1;   // increment time

            // if running and times are equal
            if (running && endTime == currentTime){

                processOutput.println("Process " + runP.getID() + " finished at " + endTime + "\n");

                // process IS NOT running
                running = false;
            }
        }

        processOutput.println("Process " + runP.getID() + " finished at " + endTime + "\n");
        // write total wait times
        processOutput.println("Total wait time = " + avgWaitTime);
        // calc avg time for processes
        avgWaitTime /= numProcesses;
        // write avg time
        processOutput.println("Average wait time = " + avgWaitTime);
        // close writer
        processOutput.close();

    }
}