import java.util.Comparator;

// method to compare 2 objects that implements Javas Comparator
// Inputs object a and b
// Outputs comparison of a and b
public class DefaultComparator<E> implements Comparator<E>{

    @SuppressWarnings({"unchecked"})
    public int compare(E a, E b) throws ClassCastException{
        return ((Comparable<E>)a).compareTo(b);
    }

}
