import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;

public class Hw4_P6 {

    public static void main(String[] args){

        HashMap<String,Integer> myMap = new HashMap<>();        // Create empty HashMap
        ArrayList<Integer> myArrayList = new ArrayList<>();     // Create empty ArrayList
        LinkedList<Integer> myLinkedList = new LinkedList<>();  // Create empty LinkedList
        long startTime, endTime, elapsedTime;                   // Create local long variables startTime, endTime, and elapsedTime

        long hkInsert = 0, alInsert = 0, llInsert = 0, hkSearch = 0, alSearch = 0, llSearch = 0;
        int iKeys = 0;

        // for loop to run this 10 times
        for (int count = 0; count < 10; count++) {

            int[] insertKeys = new int[100000];                     // Create int array 'insertKeys' with size of 100,000
            int[] searchKeys = new int[100000];                     // Create int array 'searchKeys' with size of 100,000
            iKeys = insertKeys.length;

            Random r = new Random(1000000);                // Randomly generate numbers up to 1,000,000

            // For loop starting with i = 0, looping while i < array length, and adding 1 to i at the end
            for (int i = 0; i < insertKeys.length; i++) {

                // array at i is equal to random number between 1, 1,000,000 + 1
                insertKeys[i] = r.nextInt(1, 1000000) + 1;
            }


            //  START OF HASHMAP KEY INSERTION

            startTime = System.nanoTime();  // Set startTime to systems current nano time before loop

            // For loop starting with i = 0, looping while i < array length, and adding 1 to i at the end
            for (int i = 0; i < insertKeys.length; i++) {

                String s = Integer.toString(i);
                // Add key (1) with values of [i] to myMap
                myMap.put(s, insertKeys[i]);
            }
            endTime = System.nanoTime();    // Set endTime to systems current nano time after loop completes
            elapsedTime = endTime - startTime;    // average elapsed time = end time of loop minus start time of loop
            hkInsert = elapsedTime;

            // END OF HASHMAP KEY INSERTION


            //  START OF ARRAYLIST KEY INSERTION

            startTime = System.nanoTime();  // Set startTime to systems current nano time before loop

            // For loop starting with i = 0, looping while i < array length, and adding 1 to i at the end
            for (int i = 0; i < insertKeys.length; i++) {

                // Add [i] to ArrayList
                myArrayList.add(insertKeys[i]);
            }
            endTime = System.nanoTime();    // Set endTime to systems current nano time after loop completes
            elapsedTime = endTime - startTime;    // average elapsed time = end time of loop minus start time of loop
            alInsert = elapsedTime;

            // END OF ARRAYLIST KEY INSERTION


            //  START OF LINKEDLIST KEY INSERTION

            startTime = System.nanoTime();  // Set startTime to systems current nano time before loop

            // For loop starting with i = 0, looping while i < array length, and adding 1 to i at the end
            for (int i = 0; i < insertKeys.length; i++) {

                // Add [i] to LinkedList
                myLinkedList.add(insertKeys[i]);
            }
            endTime = System.nanoTime();    // Set endTime to systems current nano time after loop completes
            elapsedTime = endTime - startTime;    // average elapsed time = end time of loop minus start time of loop
            llInsert = elapsedTime;

            // END OF LINKEDLIST KEY INSERTION


            r.setSeed(2000000);                  // set the Random seed from 1,000,000 to 2,000,000

            // For loop starting with i = 0, looping while i < array length, and adding 1 to i at the end
            for (int i = 0; i < searchKeys.length; i++) {

                // array at i is equal to random number between 1, 2,000,000 + 1
                searchKeys[i] = r.nextInt(1, 2000000) + 1;
            }


            //  START OF HASHMAP KEY SEARCH

            startTime = System.nanoTime();  // Set startTime to systems current nano time before loop

            // For loop starting with i = 0, looping while i < array length, and adding 1 to i at the end
            for (int i = 0; i < searchKeys.length; i++) {

                // Search HashMap for [i]
                myMap.containsKey(searchKeys[i]);
            }
            endTime = System.nanoTime();    // Set endTime to systems current nano time after loop completes
            elapsedTime = endTime - startTime;    // average elapsed time = end time of loop minus start time of loop
            hkSearch = elapsedTime;

            // END OF HASHMAP KEY SEARCH


            //  START OF ARRAYLIST KEY SEARCH

            startTime = System.nanoTime();  // Set startTime to systems current nano time before loop

            // For loop starting with i = 0, looping while i < array length, and adding 1 to i at the end
            for (int i = 0; i < searchKeys.length; i++) {

                // Search arraylist for [i]
                myArrayList.contains(searchKeys[i]);
            }
            endTime = System.nanoTime();    // Set endTime to systems current nano time after loop completes
            elapsedTime = endTime - startTime;    // average elapsed time = end time of loop minus start time of loop
            alSearch = elapsedTime;

            // END OF ARRAYLIST KEY SEARCH


            //  START OF LINKEDLIST KEY SEARCH

            startTime = System.nanoTime();  // Set startTime to systems current nano time before loop

            // For loop starting with i = 0, looping while i < array length, and adding 1 to i at the end
            for (int i = 0; i < searchKeys.length; i++) {

                // Search linkedlist for [i]
                myLinkedList.contains(searchKeys[i]);
            }
            endTime = System.nanoTime();    // Set endTime to systems current nano time after loop completes
            elapsedTime = endTime - startTime;    // average elapsed time = end time of loop minus start time of loop
            llSearch = elapsedTime;

            //  END OF LINKEDLIST KEY SEARCH


            // Setting default value to empty array
            for (int i = 0; i < insertKeys.length; i++) {
                insertKeys[i] = 0;
                searchKeys[i] = 0;
            }
            myMap.clear();
            myArrayList.clear();
            myLinkedList.clear();

        }

        System.out.println("Number of keys:" + " " + iKeys);    // Print array length
        System.out.println();   // extra line
        System.out.println("HashMap average total insert time =" + " " + hkInsert / 10); // Print elapsed time of hashmap key insertion
        System.out.println("ArrayList average total insert time =" + " " + alInsert / 10); // Print elapsed time of arraylist key insertion
        System.out.println("LinkedList average total insert time =" + " " + llInsert / 10); // Print elapsed time of linkedlist key insertion
        System.out.println();   // extra line
        System.out.println("HashMap average total search time =" + " " + hkSearch / 10); // Print elapsed time of hashmap key search
        System.out.println("ArrayList average total search time =" + " " + alSearch / 10); // Print elapsed time of arraylist search
        System.out.println("LinkedList average total search time =" + " " + llSearch / 10); // Print elapsed time of linkedlist key search

    }

}