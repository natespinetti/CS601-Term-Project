import java.util.Random;

public class HW5_P7 {

    // Source of Insertion Sort: Data Structures and Algorithms in Java Page 111
    public static void insertionSort(int[] arr)
    {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i;

            while (j > 0 && arr[j - 1] > key) {
                arr[j] = arr[j - 1];
                j--;
            }
            arr[j] = key;
        }
    }


    // Source of Merge Sort: https://www.geeksforgeeks.org/merge-sort/?ref=lbp
    public static void merge(int[] arr, int l, int m, int r)
    {
        // Find sizes of two subarrays to be merged
        int n1 = m - l + 1;
        int n2 = r - m;

        /* Create temp arrays */
        int[] L = new int[n1];
        int[] R = new int[n2];

        /*Copy data to temp arrays*/
        for (int i = 0; i < n1; ++i)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; ++j)
            R[j] = arr[m + 1 + j];

        /* Merge the temp arrays */

        // Initial indexes of first and second subarrays
        int i = 0, j = 0;

        // Initial index of merged subarray array
        int k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            }
            else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        /* Copy remaining elements of L[] if any */
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        /* Copy remaining elements of R[] if any */
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    public static void mergeSort(int[] arr, int l, int r)
    {
        if (l < r) {
            // Find the middle point
            int m =l+ (r-l)/2;

            // Sort first and second halves
            mergeSort(arr, l, m);
            mergeSort(arr, m + 1, r);

            // Merge the sorted halves
            merge(arr, l, m, r);
        }
    }

// Source of Quick Sort: https://www.geeksforgeeks.org/quick-sort/?ref=lbp
    static void quickSortSwap(int[] arr, int i, int j)
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    /* This function takes last element as pivot, places the pivot element at its correct position in sorted
       array, and places all smaller (smaller than pivot) to left of pivot and all greater elements to right
       of pivot */
    static int quickSortPartition(int[] arr, int low, int high)
    {

        // pivot
        int pivot = arr[high];

        // Index of smaller element and indicates the right position of pivot found so far
        int i = (low - 1);

        for(int j = low; j <= high - 1; j++)
        {

            // If current element is smaller than the pivot
            if (arr[j] < pivot)
            {

                // Increment index of smaller element
                i++;
                quickSortSwap(arr, i, j);
            }
        }
        quickSortSwap(arr, i + 1, high);
        return (i + 1);
    }

    /* The main function that implements QuickSort
              arr[] --> Array to be sorted, low --> Starting index, high --> Ending index
     */
    public static void quickSort(int[] arr, int low, int high)
    {
        if (low < high)
        {
            // pi is partitioning index, arr[p] is now at right place
            int pi = quickSortPartition(arr, low, high);

            // Separately sort elements before partition and after partition
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    // Source of Heap Sort: https://www.geeksforgeeks.org/heap-sort/?ref=lbp
    public static void heapSort(int[] arr)
    {
        int n = arr.length;

        // Build heap (rearrange array)
        for (int i = n / 2 - 1; i >= 0; i--)
            heapify(arr, n, i);

        // One by one extract an element from heap
        for (int i = n - 1; i > 0; i--) {
            // Move current root to end
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            // call max heapify on the reduced heap
            heapify(arr, i, 0);
        }
    }

    // To heapify a subtree rooted with node i which is an index in arr[]. n is size of heap
    public static void heapify(int[] arr, int n, int i)
    {
        int largest = i; // Initialize largest as root
        int l = 2 * i + 1; // left = 2*i + 1
        int r = 2 * i + 2; // right = 2*i + 2

        // If left child is larger than root
        if (l < n && arr[l] > arr[largest])
            largest = l;

        // If right child is larger than largest so far
        if (r < n && arr[r] > arr[largest])
            largest = r;

        // If largest is not root
        if (largest != i) {
            int swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;

            // Recursively heapify the affected sub-tree
            heapify(arr, n, largest);
        }
    }

        public static void main(String[] args) {

        Random r = new Random();    // generate random number
        int index = 0;              // set index to 0
        int[] b, c, d;              // initialize arrays b, c, and d
        int n = 10000;              // set n to 10000

        long startTime, endTime, elapsedTime;   // initialize start, end, and elapsed times
        long[] timeInsertion = new long[10], timeMerge = new long[10],    // create the arrays to store the elapsed times
                timeQuick = new long[10], timeHeap = new long[10];

        // for loop to run this 10 times, has extra parameter to make sure n doesn't exceed 100k
        for (int count = 0; count < 10 && n <= 100000; count++){

            // array with size n
            int[] arr = new int[n];

            // fill array with random integers between 1 and 1mil until array reaches size n
            for (int i = 0; i < arr.length; i++){
                arr[i] = r.nextInt(1, 1000000) + 1;
            }

            // clone the above array so we can sort with the different algorithms
            b = arr.clone();
            c = arr.clone();
            d = arr.clone();

            // START OF INSERTION SORT

            startTime = System.currentTimeMillis(); // Set startTime to systems current milliseconds time before sorting
            insertionSort(arr); // Run insertion on original array
            endTime = System.currentTimeMillis(); // Set endTime to systems current milliseconds time after sorting completes
            elapsedTime = endTime - startTime; // average elapsed time = end time of sort minus start time of sort
            timeInsertion[index] = elapsedTime; // set element at index to be elapsedTime

            // END OF INSERTION SORT


            // START OF MERGE SORT

            startTime = System.currentTimeMillis(); // Set startTime to systems current milliseconds time before sorting
            mergeSort(b, 0, b.length-1); // Run merge sort on 1st arr copy
            endTime = System.currentTimeMillis(); // Set endTime to systems current milliseconds time after sorting completes
            elapsedTime = endTime - startTime; // average elapsed time = end time of sort minus start time of sort
            timeMerge[index] = elapsedTime; // set element at index to be elapsedTime

            // END OF MERGE SORT


            // START OF QUICK SORT

            startTime = System.currentTimeMillis(); // Set startTime to systems current milliseconds time before sorting
            quickSort(c, 0, c.length-1); // Run quick sort on 2nd arr copy
            endTime = System.currentTimeMillis(); // Set endTime to systems current milliseconds time after sorting completes
            elapsedTime = endTime - startTime; // average elapsed time = end time of sort minus start time of sort
            timeQuick[index] = elapsedTime; // set element at index to be elapsedTime

            // END OF QUICK SORT


            // START OF HEAP SORT

            startTime = System.currentTimeMillis(); // Set startTime to systems current milliseconds time before sorting
            heapSort(d); // Run heap sort on 3rd arr copy
            endTime = System.currentTimeMillis(); // Set endTime to systems current milliseconds time after sorting completes
            elapsedTime = endTime - startTime; // average elapsed time = end time of sort minus start time of sort
            timeHeap[index] = elapsedTime; // set element at index to be elapsedTime

            // END OF HEAP SORT

            index++; // Move +1 in the 'time-keeper' arrays

            n = n + 10000; // Add 10000 to the size of n so array size increases each loop

        }

            // Print the different sizes up to 100k
            System.out.println("Algorithm\t10000\t20000\t30000\t40000\t50000\t60000\t70000\t80000\t90000\t100000");
            System.out.println();

            // For loop to print insertions time and add tabs for lining up
            System.out.print("insertion\t");
            for(long i : timeInsertion){
                System.out.print(i+"\t\t");
            }
            System.out.println();

            // For loop to print merge time and add tabs for lining up
            System.out.print("merge sort\t");
            for(long i : timeMerge){
                System.out.print(i+"\t\t");
            }
            System.out.println();

            // For loop to print quick time and add tabs for lining up
            System.out.print("quick sort\t");
            for(long i : timeQuick){
                System.out.print(i+"\t\t");
            }
            System.out.println();

            // For loop to print heap time and add tabs for lining up
            System.out.print("heap sort\t");
            for(long i : timeHeap){
                System.out.print(i+"\t\t");
            }

    }

}
