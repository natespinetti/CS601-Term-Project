package nodeTrees;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// binary search tree storing integers
public class IntBST extends NodeBinaryTree<Integer> {

	private int size = 0;
	
	public IntBST() {	}

	public int size() {
		return size;
	}

	public void setSize(int s) { size = s; }
	
	public boolean isEmpty() {
		return size() == 0;
	}

	/**
	 * Places element e at the root of an empty tree and returns its new Node.
	 *
	 * @param e the new element
	 * @return the Node of the new element
	 * @throws IllegalStateException if the tree is not empty
	 */

	public Node<Integer> addRoot(Integer e) throws IllegalStateException {
		if (size != 0)
			throw new IllegalStateException("Tree is not empty");
		root = createNode(e, null, null, null);
		size = 1;
		return root;
	}

	/**
	 * Print a binary tree horizontally Modified version of
	 * https://stackoverflow.com/questions/4965335/how-to-print-binary-tree-diagram
	 * Modified by Keith Gutfreund
	 * 
	 * @param n Node in tree to start printing from
	 */
	
	  public void print(Node<Integer> n){ print ("", n); }
	  
	  public void print(String prefix, Node<Integer> n){
		  if (n != null){
			  print(prefix + "       ", right(n));
			  System.out.println (prefix + ("|-- ") + n.getElement());
			  print(prefix + "       ", left(n));
		  }
	  }
	  
	  
	  public void inorderPrint(Node<Integer> n) {
		if (n == null)
			return;
		inorderPrint(n.getLeft());
		System.out.print(n.getElement() + "  ");
		inorderPrint(n.getRight());
	}

	
	public Iterable<Node<Integer>> children(Node<Integer> n) {
		List<Node<Integer>> snapshot = new ArrayList<>(2); // max capacity of 2 
		if (left(n) != null) 
			snapshot.add(left(n)); 
		if (right(n) != null)
			snapshot.add(right(n)); return snapshot; 
	}
	
	public int height(Node<Integer> n) throws IllegalArgumentException { 
		if (isExternal(n)) { return 0; } 
		int h = 0; // base case if p is external
		for (Node<Integer> c : children(n)) h = Math.max(h, height(c)); return h + 1; 
	}


	// Return the 'recursive' method btBuilder to main
	public static IntBST makeBinaryTree(int[] a){
		// complete this method

		return btBuilder(a, 0, a.length-1);
	}


	// SINCE I CAN'T FIGURE OUT HOW TO CODE THIS AT ALL, I'M GOING TO EXPLAIN HOW I WISH IT WORKED
	// 1. Create trees
	// 2. Find mid point of array and set it to root
	// 3. Create subarray from the left to mid-1
	// 4. Find mid point of subarray, set root
	// 5. Left of new root becomes subarray, find mid, set root (same for right side)
	// 6. When there are no more mid points to be set, set left and right child if possible
	// 7. Repeat steps 4-6 on new subarray from mid+1 to right
	// 8. Attach the left and right trees to main tree via root
	public static IntBST btBuilder(int[] a, int left, int right) {

		int mid = a.length/2;

		IntBST tree = new IntBST();
		IntBST leftTree = new IntBST();
		IntBST rightTree = new IntBST();
		Node root = tree.addRoot(a[mid]);

		if (left > right){
			return null;
		}

		  else {
			int[] lTree = Arrays.copyOfRange(a, left, a[mid-1]);
			int lMid = mid/2;
			int x = lTree[lMid-2];
			int y = lTree[lMid+2];
			Node lRoot = leftTree.addRoot(lTree[lMid]);
			leftTree.addLeft(lRoot, x);
			leftTree.addRight(lRoot, y);


			btBuilder(a, left, right-1);
//
//
//			int[] rTree = Arrays.copyOfRange(a, a[mid+1], right);
//			int rMid = mid+2;
//			int e = rTree[rMid/2];
//			int f = rTree[rMid+2];
//			Node rRoot = rightTree.addRoot(rTree[rMid]);
//			rightTree.addLeft(rRoot, x);
//			rightTree.addRight(rRoot, y);
//
			tree.attach(root, leftTree, rightTree);
//
//			btBuilder(a, left+1, right);
		}

//
//		  if (startBT < endBT){
//			  int temp = a[mid];
//			  root = temp;
//		  }



//		Node root = tree.addRoot(mid);
//
//
//
//
//
//
//		Node start = leftTree.addLeft(lRoot, lMiddle - 1);
//		start.setParent(lRoot);
//		Node end = leftTree.addRight(lRoot, lMiddle + 1);
//		end.setParent(lRoot);
//
//		btBuilder(a, startBT, middle - 1);
//
//
//		int rMiddle = middle*2;
//		int rMid = a[rMiddle];
//		Node rRoot = rightTree.addRoot(rMid);
//
//		Node rChildl = rightTree.addLeft(rRoot, rMiddle - 1);
//		Node rChildr = rightTree.addRight(rRoot, rMiddle + 1);
//
//		rChildl = rChildr = rRoot;
//
//		rightTree.addLeft(rRoot, middle - 1);
//		rightTree.addRight(rRoot, middle + 1);
//
//		btBuilder(a, middle + 1, endBT);


//



//		int mid = (startBT + endBT) / 2;
//		int r = a[mid];
//
//


//
//
//		Node root = tree.addRoot(r);
//		Node lRoot = leftTree.addRoot(lTree[r]);
//		Node rRoot = rightTree.addRoot(rTree[r]);
//
//		leftTree.addLeft(root, mid-1);
//		leftTree.addRight(root, mid+1);
//
//		btBuilder(lTree, startBT, mid-1);
////		btBuilder(rTree, mid+1, endBT);
//
//
//		tree.attach(root, leftTree, rightTree);



//
//		int roots = a[mid];
//
//		int lMiddle = mid / 2;
//		int lMid = a[lMiddle];
//		Node lRoot = leftTree.addRoot(lMid);
//
//
//		int rMiddle = (mid * 2) - lMiddle;
//		int rMid = a[rMiddle];
//		Node rRoot = rightTree.addRoot(rMid);
//
//		Node start = lRoot.getLeft();

////			startBT = a[lMiddle-1];
////			leftTree.addLeft(lRoot, startBT);
////			endBT = a[lMiddle+1];
////			leftTree.addRight(lRoot, endBT);
////			lRoot.getLeft().setParent(lRoot);
//			lRoot.setLeft(start);
//			btBuilder(a, startBT, mid - 1);

//			public static void recursiveHelper(DoublyLinkedList<Integer> intList, DoubleLinkNode index){
//
//				DoubleLinkNode<Integer> trailer = intList.getTrailer();
//				DoubleLinkNode<Integer> last = trailer.getPrev();
			//				last.getPrev().setNext(trailer);
//				trailer.setPrev(last.getPrev());
//
//				last.setNext(index.getNext());
//				index.getNext().setPrev(last);
//				index.setNext(last);
//				last.setPrev(index);
//	}

//		if (mid >= a[lMiddle + 1]) {
//			leftTree.addRight(lRoot, lMid);
//			btBuilder(a, lMiddle + 1, endBT);
//		}
//
//		if (startBT <= rMid - 1){
//			rightTree.addLeft(rRoot, rMiddle);
//			btBuilder(a, startBT, rMiddle - 1);
//		}
//
//		if (mid >= rMid + 1) {
//			rightTree.addRight(rRoot, rMiddle);
//			btBuilder(a, rMiddle + 1, endBT);
//		}



//		public static List<Integer> fillBST(List<Integer> b, List<Integer> nums, int start, int end) {
//			int mid = (int)Math.round((1.0 * start + end) / 2);
//			b.add(nums.get(mid));
//			if (start <= mid - 1)
//				fillBST(b, nums, start, mid - 1);
//			if (end >= mid + 1)
//				fillBST(b, nums, mid + 1, end);
//			return b;
//		}







//		IntBST rightTree = btBuilder(a, middle + 1, endBT);


//		public static void recursiveHelper(DoublyLinkedList<Integer> intList, DoubleLinkNode index){
//
//			DoubleLinkNode<Integer> trailer = intList.getTrailer();
//			DoubleLinkNode<Integer> last = trailer.getPrev();
//
//			if (last == index) {
//				return;
//			}
//			else {
//				last.getPrev().setNext(trailer);
//				trailer.setPrev(last.getPrev());
//
//				last.setNext(index.getNext());
//				index.getNext().setPrev(last);
//				index.setNext(last);
//				last.setPrev(index);
//
//				index = last;
//
//				recursiveHelper(intList, index);
//			}
//
//		}


		return tree;
	}

}
